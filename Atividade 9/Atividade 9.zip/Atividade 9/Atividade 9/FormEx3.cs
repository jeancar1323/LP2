﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_9
{
    public partial class FormEx3 : Form
    {
        public FormEx3()
        {
            InitializeComponent();
        }

        private void btnGetRes_Click(object sender, EventArgs e)
        {
            string[] students = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
           int total = 0;
            
            for (int i = 0; i < (students.Length - 1); i++) {
                total += students[i].Length;
            }
            MessageBox.Show($"O total é {total}");
        }
    }
}
