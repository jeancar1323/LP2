﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_9
{
    public partial class FormEx6 : Form
    {
        public FormEx6()
        {
            InitializeComponent();
        }

        private void btnCalcMed_Click(object sender, EventArgs e)
        {
            double[,] stundents = new double[20, 3];
            for (int l = 0; l < stundents.GetLength(0); l++)
            {
                double total = 0;
                for (int c = 0; c < stundents.GetLength(1); c++)
                {
                    if (!double.TryParse(Interaction.InputBox($"Digite a nota n: {l + 1} do aluno {c+1}", "Entrada da nota"), out stundents[l,c]) || stundents[l, c] > 10)
                    {
                        MessageBox.Show("Valor não é uma nota valida");
                        c--;
                    }else
                        total += stundents[l, c];
                    
                    
                }

                MessageBox.Show($"A media do aluno {l + 1} é de {total / 3d}");
            }
        }
    }
}


