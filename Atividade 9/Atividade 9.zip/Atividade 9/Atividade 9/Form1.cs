﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExer1_Click(object sender, EventArgs e)
        {
            new FormEx1().ShowDialog();
        }

        private void btnExer2_Click(object sender, EventArgs e)
        {
            new FormEx2().ShowDialog();
        }

        private void btnExer3_Click(object sender, EventArgs e)
        {
            new FormEx3().ShowDialog();
        }

        private void btnExer4_Click(object sender, EventArgs e)
        {
            new FormEx4().ShowDialog();
        }

        private void btnExer5_Click(object sender, EventArgs e)
        {
            new FormEx5().ShowDialog();
        }

        private void btnExer6_Click(object sender, EventArgs e)
        {
            new FormEx6().ShowDialog();
        }

        private void btnExer7_Click(object sender, EventArgs e)
        {
            new FormEx7().ShowDialog();
        }
    }
}
