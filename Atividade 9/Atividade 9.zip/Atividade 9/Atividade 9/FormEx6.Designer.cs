﻿
namespace Atividade_9
{
    partial class FormEx6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcMed = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCalcMed
            // 
            this.btnCalcMed.Location = new System.Drawing.Point(23, 12);
            this.btnCalcMed.Name = "btnCalcMed";
            this.btnCalcMed.Size = new System.Drawing.Size(162, 89);
            this.btnCalcMed.TabIndex = 4;
            this.btnCalcMed.Text = "Calcular notas alunos";
            this.btnCalcMed.UseVisualStyleBackColor = true;
            this.btnCalcMed.Click += new System.EventHandler(this.btnCalcMed_Click);
            // 
            // FormEx6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(212, 117);
            this.Controls.Add(this.btnCalcMed);
            this.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FormEx6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exercicio 6";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCalcMed;
    }
}