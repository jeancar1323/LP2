﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_9
{
    public partial class FormEx2 : Form
    {
        public FormEx2()
        {
            InitializeComponent();
        }

        private void btnInit_Click(object sender, EventArgs e)
        {
            int[] amountProduct = new int[10];
            double[] priceProduct = new double[10];
            double revenues = 0;

            for (int i = 0; i < amountProduct.Length; i++)
            {
                bool isOk;
                do
                {
                    if(!int.TryParse(Interaction.InputBox($"Digite a quantidade de produto  {i + 1}", "Entrada da quantidade"), out amountProduct[i]))
                    {
                        MessageBox.Show("Valor não é um numero valido");
                        isOk = false;
                    }
                    else
                    {
                        isOk = true;
                    }

                } while (!isOk);

                do
                {
                    if (!double.TryParse(Interaction.InputBox($"Digite o valor do produto  {i + 1}", "Entrada do valor"), out priceProduct[i]))
                    {
                        MessageBox.Show("Valor não é um numero valido");
                        isOk = false;
                    }
                    else
                    {
                        isOk = true;
                    }

                } while (!isOk);

                revenues += priceProduct[i] * amountProduct[i];
            }

            MessageBox.Show($"O faturamento total é de {revenues}");
        }
    }
}
