﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_9
{
    public partial class FormEx1 : Form
    {
        public FormEx1()
        {
            InitializeComponent();
        }

        private void btnInvert_Click(object sender, EventArgs e)
        {
            int[] numbers = new int[20];

            for (int i = (numbers.Length - 1); i >= 0; i--)
            {
                string getNumber = Interaction.InputBox($"Digite um numero na posição {i + 1}", "Entrada de dados");

                if (!int.TryParse(getNumber, out numbers[i]))
                {
                    MessageBox.Show("Não é um numero");
                    i++;
                }
            }
            string nInvert = "";
            foreach (int n in numbers)
            {
                nInvert += n;
            }
            MessageBox.Show(nInvert);
        }

        private void FormEx1_Load(object sender, EventArgs e)
        {

        }
    }
}
