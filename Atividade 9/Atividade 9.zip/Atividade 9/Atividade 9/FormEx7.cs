﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_9
{
    public partial class FormEx7 : Form
    {
        public FormEx7()
        {
            InitializeComponent();
        }

        private void btnCalcMed_Click(object sender, EventArgs e)
        {
            nameList.Items.Clear();
            string[] names = new string[5];
            string[] namesWithCaracters = new string[names.Length];
            for (int i = 0; i < names.Length; i++)
            {
               names[i] = Interaction.InputBox($"Digite o  {i + 1}º nome", "Entrada da quantidade");
               namesWithCaracters[i] = $"O nome: {names[i]}  tem {names[i].Replace(" ", "").Length} caracteres";
            }

            nameList.Items.AddRange(namesWithCaracters);
        }
    }
}
