﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P0030482111015
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            lbResultado.Items.Clear();
            double[,] vendas = new double[5,4];
            ArrayList msgs = new ArrayList();
            double somaMes, totalGeral = 0;
            for (int l = 0; l < vendas.GetLength(0); l++)
            {
                somaMes = 0;
                for (int c = 0; c < vendas.GetLength(1); c++)
                {
                    

                    if (!double.TryParse(Interaction.InputBox($"Digite o valor do mês: {l+1}, da semana: {c+1}",$"Entrada do mês {l+1}"), out vendas[l, c]))
                    {
                        MessageBox.Show("Valor invalido, por favor digite novamente");
                        c--;
                    }
                    else
                    {
                        somaMes += vendas[l, c];
                        msgs.Add($"Total do mês: {l+1} Semana: {c+1} {vendas[l, c].ToString("C", CultureInfo.CurrentCulture)}");
                    }
                }
                msgs.Add($">> Total Mês:  {somaMes.ToString("C", CultureInfo.CurrentCulture)} ");
                msgs.Add("------------------------------");
                totalGeral += somaMes;
            }

            msgs.Add($">> Total Geral:  {totalGeral.ToString("C", CultureInfo.CurrentCulture)}");
            lbResultado.Items.AddRange(msgs.ToArray());
        }
    }
}
