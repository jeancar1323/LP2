﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculador_de_descontos
{
    class Calculos
    {
        private double salario;
        private string nome;
        private bool casado;
        private bool feminino;
        private int filhos;

        private double descontoInss;
        private string descontoInssText;

        private double descontoIrpf;
        private string descontoIrpfText;


        public Calculos(string nome, double salario, bool casado, bool feminino, int filhos)
        {
            this.nome = nome;
            this.salario = salario;
            this.casado = casado;
            this.feminino = feminino;
            this.filhos = filhos;
            DescontoAliInss();
            DescontoAliIrpf();
        }

        void DescontoAliInss()
        {
            if (salario < 800.47)
            {
                descontoInss = 0.0765 * salario;
                descontoInssText = "7.65%";
            }
            else if (salario <= 1050)
            {
                descontoInss = 0.0865 * salario;
                descontoInssText = "8.65%";
            }
            else if (salario <= 1400.77)
            {
                descontoInss = 0.09 * salario;
                descontoInssText = "9.00";
            }
            else if (salario <= 2801.56)
            {
                descontoInss = 0.11 * salario;
                descontoInssText = "11.00%";
            }
            else
            {
                descontoInss = 308.17;
                descontoInssText = "R$ 308,17 (fixo)";
            }
        }

        public string getDescontoInssText()
        {
            return descontoInssText;
        }
        public double getDescontoInss()
        {
            return descontoInss;
        }

        void DescontoAliIrpf()
        {
            if (salario < 1257.12)
            {
                descontoIrpf = 0;
                descontoIrpfText = "Isento";
            }
            else if (salario <= 2512.08)
            {
                descontoIrpf = 0.15 * salario;
                descontoIrpfText = "15.00%";
            }
            else
            {
                descontoIrpf = 0.275 * salario;
                descontoIrpfText = "25.50%";
            }
        }

        public string getDescontoIrpfText()
        {
            return descontoIrpfText;
        }
        public double getDescontoIrpf()
        {
            return descontoIrpf;
        }

        public double getSalarioLiquido()
        {
            return salario - (descontoInss + descontoIrpf);
        }

        public double getSalarioFamilia()
        {
            if (salario < 435.52)
                return filhos * 22.33;
            else if (salario <= 657.61)
                return filhos * 15.74;
            else
                return 0;
        }

        public string getMensagem()
        {
            return $"Os descontos do salario {(feminino? "da Sra": "do Sr")} {nome} que é {(casado ? "casado(a)" : "solteiro(a)")} e tem {filhos} filhos(a) são : ";
        }
    }
}
