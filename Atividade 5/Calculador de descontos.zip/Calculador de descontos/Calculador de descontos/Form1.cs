﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculador_de_descontos
{
    public partial class Form1 : Form
    {
        //deveria ter pensando em um nome melhor 
        Calculos calculos;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbSexo.SelectedIndex = 0;
        }


        private void textboxApenasLetras_TextChanged(object sender, KeyPressEventArgs e)
        {

            //apenas deixar digitar letras  
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            if (!VerificarCampos())
                return;

            try
            {
                calculos = new Calculos(tbNome.Text, Double.Parse(mtbSalarioBruto.Text), chbCasado.Checked, (cbSexo.SelectedIndex == 0), Convert.ToInt32(numFilhos.Value));
                tbAliInns.Text = calculos.getDescontoInssText();
                mtbDescInss.Text = calculos.getDescontoInss().ToString("N2", new CultureInfo("pt-BR"));
                tbAliIrpf.Text = calculos.getDescontoIrpfText();
                mtbDescIrpf.Text = calculos.getDescontoIrpf().ToString("N2", new CultureInfo("pt-BR"));
                mtbSalLiquido.Text = calculos.getSalarioLiquido().ToString("N2", new CultureInfo("pt-BR"));
                mtbSalFamilia.Text = calculos.getSalarioFamilia().ToString("N2", new CultureInfo("pt-BR"));
                gbResultados.Text = calculos.getMensagem();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Campos invalido");
            }
            
        }


        bool VerificarCampos()
        {
            if (String.IsNullOrEmpty(tbNome.Text))
            {
                MessageBox.Show("Campo nome não pode estar vazio");
                return false;
            }

            if (!Double.TryParse(mtbSalarioBruto.Text, out double num))
            {
                MessageBox.Show("Campos salario não pode estar vazio");
                return false;
            }

            return true;
        }
    }
}

