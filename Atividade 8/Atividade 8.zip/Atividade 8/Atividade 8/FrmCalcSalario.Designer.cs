﻿
namespace Atividade_8
{
    partial class FrmCalcSalario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnVerificarPali = new System.Windows.Forms.Button();
            this.tbNome = new System.Windows.Forms.TextBox();
            this.tbCargo = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.tbMatricuka = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbProdu = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbSalario = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbGratifica = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Roboto", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 28);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nome";
            // 
            // btnVerificarPali
            // 
            this.btnVerificarPali.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnVerificarPali.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVerificarPali.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificarPali.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnVerificarPali.Location = new System.Drawing.Point(77, 238);
            this.btnVerificarPali.Name = "btnVerificarPali";
            this.btnVerificarPali.Size = new System.Drawing.Size(204, 45);
            this.btnVerificarPali.TabIndex = 2;
            this.btnVerificarPali.Text = "Calcular";
            this.btnVerificarPali.UseVisualStyleBackColor = false;
            this.btnVerificarPali.Click += new System.EventHandler(this.btnVerificarPali_Click);
            // 
            // tbNome
            // 
            this.tbNome.Location = new System.Drawing.Point(8, 40);
            this.tbNome.Name = "tbNome";
            this.tbNome.Size = new System.Drawing.Size(145, 26);
            this.tbNome.TabIndex = 3;
            // 
            // tbCargo
            // 
            this.tbCargo.Location = new System.Drawing.Point(8, 100);
            this.tbCargo.Name = "tbCargo";
            this.tbCargo.Size = new System.Drawing.Size(145, 26);
            this.tbCargo.TabIndex = 5;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Roboto", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(3, 69);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(67, 28);
            this.label45.TabIndex = 4;
            this.label45.Text = "Cargo";
            // 
            // tbMatricuka
            // 
            this.tbMatricuka.Location = new System.Drawing.Point(8, 172);
            this.tbMatricuka.Name = "tbMatricuka";
            this.tbMatricuka.Size = new System.Drawing.Size(145, 26);
            this.tbMatricuka.TabIndex = 7;
            this.tbMatricuka.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textboxApenasNumeros_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Roboto", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 141);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 28);
            this.label3.TabIndex = 6;
            this.label3.Text = "Matrícula";
            // 
            // tbProdu
            // 
            this.tbProdu.Location = new System.Drawing.Point(208, 40);
            this.tbProdu.Name = "tbProdu";
            this.tbProdu.Size = new System.Drawing.Size(145, 26);
            this.tbProdu.TabIndex = 9;
            this.tbProdu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textboxApenasNumeros_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Roboto", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(203, 9);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 28);
            this.label4.TabIndex = 8;
            this.label4.Text = "Produção";
            // 
            // tbSalario
            // 
            this.tbSalario.Location = new System.Drawing.Point(208, 100);
            this.tbSalario.Name = "tbSalario";
            this.tbSalario.Size = new System.Drawing.Size(145, 26);
            this.tbSalario.TabIndex = 11;
            this.tbSalario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textboxApenasNumeros_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Roboto", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(203, 69);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 28);
            this.label5.TabIndex = 10;
            this.label5.Text = "Salario";
            // 
            // tbGratifica
            // 
            this.tbGratifica.Location = new System.Drawing.Point(208, 172);
            this.tbGratifica.Name = "tbGratifica";
            this.tbGratifica.Size = new System.Drawing.Size(145, 26);
            this.tbGratifica.TabIndex = 13;
            this.tbGratifica.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textboxApenasNumeros_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Roboto", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(203, 141);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 28);
            this.label6.TabIndex = 12;
            this.label6.Text = "Gratificação";
            // 
            // FrmCalcSalario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(394, 342);
            this.Controls.Add(this.tbGratifica);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbSalario);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbProdu);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbMatricuka);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbCargo);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.tbNome);
            this.Controls.Add(this.btnVerificarPali);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmCalcSalario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calcular salario";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnVerificarPali;
        private System.Windows.Forms.TextBox tbNome;
        private System.Windows.Forms.TextBox tbCargo;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox tbMatricuka;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbProdu;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbSalario;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbGratifica;
        private System.Windows.Forms.Label label6;
    }
}