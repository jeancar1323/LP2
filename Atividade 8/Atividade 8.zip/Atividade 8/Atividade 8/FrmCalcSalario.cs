﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_8
{
    public partial class FrmCalcSalario : Form
    {

        double salario, gratificao;
        int prod;
        int b = 0, c = 0, d = 0;
        public FrmCalcSalario()
        {
            InitializeComponent();
        }

        private void textboxApenasNumeros_TextChanged(object sender, KeyPressEventArgs e)
        {

            //verifica qual tecla foi pressionada, se for alguma diferente de numero, virgula ou sinal negativo não é registrada   
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ',') && (e.KeyChar != '-'))
            {
                e.Handled = true;
            }

          

            //verifica se ja tem uma virgula
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }

        }



        private void btnVerificarPali_Click(object sender, EventArgs e)
        {
            VerificarCampo();

            if (prod >= 100)
                b = 1;
            if (prod >= 120)
                c = 1;
            if (prod >= 150)
                d = 1;

            double valor = salario + salario * ((0.05 * b) + (0.1 * c) + (0.1 * d)) + gratificao;
            if (valor > 7000 && prod < 150 || gratificao == 0){
                valor = 7000;
            }

            MessageBox.Show($"O salario bruto do funcionario {tbNome.Text} com o cargo de {tbCargo.Text} é de {valor}");
        }

        private bool VerificarCampo()
        {
            if (string.IsNullOrEmpty(tbNome.Text) || string.IsNullOrEmpty(tbCargo.Text) ||string.IsNullOrEmpty(tbMatricuka.Text) ||
                string.IsNullOrEmpty(tbProdu.Text) || string.IsNullOrEmpty(tbSalario.Text) || string.IsNullOrEmpty(tbGratifica.Text)) {
                MessageBox.Show("Todos os campos devem ser preenchidos");
                return false;
            }
                
            if(!Double.TryParse(tbSalario.Text, out salario) || !Double.TryParse(tbGratifica.Text, out  gratificao) || !Int32.TryParse(tbProdu.Text, out  prod))
            {
                MessageBox.Show("Campos numericos invalidos");
                return false;
            }

            return true;            
        }


    }
}
