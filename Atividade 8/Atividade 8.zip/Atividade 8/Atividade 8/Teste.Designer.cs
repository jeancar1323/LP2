﻿
namespace Atividade_8
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnContFras = new System.Windows.Forms.Button();
            this.btnGenNumber = new System.Windows.Forms.Button();
            this.btnPali = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnContFras
            // 
            this.btnContFras.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnContFras.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnContFras.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContFras.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnContFras.Location = new System.Drawing.Point(50, 84);
            this.btnContFras.Name = "btnContFras";
            this.btnContFras.Size = new System.Drawing.Size(186, 45);
            this.btnContFras.TabIndex = 0;
            this.btnContFras.Text = "1) Contador de frases";
            this.btnContFras.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnContFras.UseVisualStyleBackColor = false;
            // 
            // btnGenNumber
            // 
            this.btnGenNumber.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnGenNumber.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGenNumber.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenNumber.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnGenNumber.Location = new System.Drawing.Point(50, 152);
            this.btnGenNumber.Name = "btnGenNumber";
            this.btnGenNumber.Size = new System.Drawing.Size(186, 45);
            this.btnGenNumber.TabIndex = 1;
            this.btnGenNumber.Text = "2) Gerador numeros";
            this.btnGenNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGenNumber.UseVisualStyleBackColor = false;
            // 
            // btnPali
            // 
            this.btnPali.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnPali.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPali.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPali.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnPali.Location = new System.Drawing.Point(50, 214);
            this.btnPali.Name = "btnPali";
            this.btnPali.Size = new System.Drawing.Size(186, 45);
            this.btnPali.TabIndex = 2;
            this.btnPali.Text = "3) Palíndromo";
            this.btnPali.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPali.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DodgerBlue;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button3.Location = new System.Drawing.Point(50, 283);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(186, 45);
            this.button3.TabIndex = 3;
            this.button3.Text = "4) Calculo salario";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(297, 395);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnPali);
            this.Controls.Add(this.btnGenNumber);
            this.Controls.Add(this.btnContFras);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnContFras;
        private System.Windows.Forms.Button btnGenNumber;
        private System.Windows.Forms.Button btnPali;
        private System.Windows.Forms.Button button3;
    }
}

