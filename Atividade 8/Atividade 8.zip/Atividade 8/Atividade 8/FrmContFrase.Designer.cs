﻿
namespace Atividade_8
{
    partial class FrmContFrase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtbFrase = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnNumEspcBranc = new System.Windows.Forms.Button();
            this.btnNumR = new System.Windows.Forms.Button();
            this.btnNumPars = new System.Windows.Forms.Button();
            this.btnVoltar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtbFrase
            // 
            this.rtbFrase.Location = new System.Drawing.Point(73, 42);
            this.rtbFrase.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rtbFrase.MaxLength = 100;
            this.rtbFrase.Name = "rtbFrase";
            this.rtbFrase.Size = new System.Drawing.Size(403, 178);
            this.rtbFrase.TabIndex = 0;
            this.rtbFrase.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Roboto", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(96, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(339, 28);
            this.label1.TabIndex = 1;
            this.label1.Text = "Escreva sua frase de até 100 letras";
            // 
            // btnNumEspcBranc
            // 
            this.btnNumEspcBranc.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnNumEspcBranc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNumEspcBranc.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumEspcBranc.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnNumEspcBranc.Location = new System.Drawing.Point(173, 228);
            this.btnNumEspcBranc.Name = "btnNumEspcBranc";
            this.btnNumEspcBranc.Size = new System.Drawing.Size(204, 45);
            this.btnNumEspcBranc.TabIndex = 2;
            this.btnNumEspcBranc.Text = "Numero de espaço em branco";
            this.btnNumEspcBranc.UseVisualStyleBackColor = false;
            this.btnNumEspcBranc.Click += new System.EventHandler(this.btnNumEspcBranc_Click);
            // 
            // btnNumR
            // 
            this.btnNumR.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnNumR.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNumR.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumR.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnNumR.Location = new System.Drawing.Point(173, 279);
            this.btnNumR.Name = "btnNumR";
            this.btnNumR.Size = new System.Drawing.Size(204, 45);
            this.btnNumR.TabIndex = 3;
            this.btnNumR.Text = "Numero de R";
            this.btnNumR.UseVisualStyleBackColor = false;
            this.btnNumR.Click += new System.EventHandler(this.btnNumR_Click);
            // 
            // btnNumPars
            // 
            this.btnNumPars.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnNumPars.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNumPars.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumPars.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnNumPars.Location = new System.Drawing.Point(173, 330);
            this.btnNumPars.Name = "btnNumPars";
            this.btnNumPars.Size = new System.Drawing.Size(204, 45);
            this.btnNumPars.TabIndex = 4;
            this.btnNumPars.Text = "Numero de par de letras";
            this.btnNumPars.UseVisualStyleBackColor = false;
            this.btnNumPars.Click += new System.EventHandler(this.btnNumPars_Click);
            // 
            // btnVoltar
            // 
            this.btnVoltar.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnVoltar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVoltar.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVoltar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnVoltar.Location = new System.Drawing.Point(173, 381);
            this.btnVoltar.Name = "btnVoltar";
            this.btnVoltar.Size = new System.Drawing.Size(204, 45);
            this.btnVoltar.TabIndex = 5;
            this.btnVoltar.Text = "Voltar";
            this.btnVoltar.UseVisualStyleBackColor = false;
            this.btnVoltar.Click += new System.EventHandler(this.btnVoltar_Click);
            // 
            // FrmContFrase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(546, 569);
            this.Controls.Add(this.btnVoltar);
            this.Controls.Add(this.btnNumPars);
            this.Controls.Add(this.btnNumR);
            this.Controls.Add(this.btnNumEspcBranc);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rtbFrase);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmContFrase";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Contador de Frases";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbFrase;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnNumEspcBranc;
        private System.Windows.Forms.Button btnNumR;
        private System.Windows.Forms.Button btnNumPars;
        private System.Windows.Forms.Button btnVoltar;
    }
}