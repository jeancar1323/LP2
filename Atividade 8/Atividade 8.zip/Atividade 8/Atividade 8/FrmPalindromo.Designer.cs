﻿
namespace Atividade_8
{
    partial class FrmPalindromo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnVerificarPali = new System.Windows.Forms.Button();
            this.tbFrase = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Roboto", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(185, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 28);
            this.label1.TabIndex = 1;
            this.label1.Text = "Escreva seu texto";
            // 
            // btnVerificarPali
            // 
            this.btnVerificarPali.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnVerificarPali.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVerificarPali.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificarPali.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnVerificarPali.Location = new System.Drawing.Point(169, 89);
            this.btnVerificarPali.Name = "btnVerificarPali";
            this.btnVerificarPali.Size = new System.Drawing.Size(204, 45);
            this.btnVerificarPali.TabIndex = 2;
            this.btnVerificarPali.Text = "Verificar se é palíndromo";
            this.btnVerificarPali.UseVisualStyleBackColor = false;
            this.btnVerificarPali.Click += new System.EventHandler(this.btnVerificarPali_Click);
            // 
            // tbFrase
            // 
            this.tbFrase.Location = new System.Drawing.Point(110, 40);
            this.tbFrase.Name = "tbFrase";
            this.tbFrase.Size = new System.Drawing.Size(341, 26);
            this.tbFrase.TabIndex = 3;
            // 
            // FrmPalindromo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(546, 171);
            this.Controls.Add(this.tbFrase);
            this.Controls.Add(this.btnVerificarPali);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmPalindromo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Palindromo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnVerificarPali;
        private System.Windows.Forms.TextBox tbFrase;
    }
}