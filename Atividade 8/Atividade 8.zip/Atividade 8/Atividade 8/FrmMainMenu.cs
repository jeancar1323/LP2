﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnContFras_Click(object sender, EventArgs e)
        {
            new FrmContFrase().ShowDialog();
        }

        private void btnGenNumber_Click(object sender, EventArgs e)
        {
            new FrmGeradorNu().ShowDialog();
        }

        private void btnPali_Click(object sender, EventArgs e)
        {
            new FrmPalindromo().ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new FrmCalcSalario().ShowDialog();
        }
    }
}
