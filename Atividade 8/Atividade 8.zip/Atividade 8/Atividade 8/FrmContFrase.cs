﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_8
{
    public partial class FrmContFrase : Form
    {
        public FrmContFrase()
        {
            InitializeComponent();
        }

        private void btnNumEspcBranc_Click(object sender, EventArgs e)
        {
            int n = 0;
            foreach (char item in rtbFrase.Text)
            {
                if (item == ' ') {
                    n++;
                }
            }

            MessageBox.Show($"Numero de espaços é de {n}");
        }

        private void btnNumR_Click(object sender, EventArgs e)
        {
            int n = 0;
            foreach (char item in rtbFrase.Text)
            {
                if (item == 'r' || item == 'R')
                {
                    n++;
                }
            }

            MessageBox.Show($"Numero de Rs é de {n}");
        }


        private void btnVoltar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnNumPars_Click(object sender, EventArgs e)
        {
            int n = 0;

            for (int i = 0; i < rtbFrase.Text.Length; i++)
            {

                if (i >= 1 && Char.ToLower(rtbFrase.Text[i]) == Char.ToLower(rtbFrase.Text[i - 1]))
                {
                    n++;
                }
            }

            MessageBox.Show($"Numero de Rs é de {n}");
        }
    }
}
