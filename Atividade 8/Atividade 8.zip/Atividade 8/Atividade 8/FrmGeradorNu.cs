﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_8
{
    public partial class FrmGeradorNu : Form
    {
        public FrmGeradorNu()
        {
            InitializeComponent();
        }

        private void btnGerar_Click(object sender, EventArgs e)
        {
            int n;
            float h = 0f;
            if (Int32.TryParse(tbNum.Text, out n) && n > 0) {
                for (float i = 1; i <= n; i++)
                {
                    h += 1/i;
                   
                }
                MessageBox.Show(h.ToString());
            }
            else
            {
                MessageBox.Show("Precisa ser um numero e ser maior que 0");
            }
        }
    }
}
