﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_8
{
    public partial class FrmPalindromo : Form
    {
        public FrmPalindromo()
        {
            InitializeComponent();
        }

        private void btnVerificarPali_Click(object sender, EventArgs e)
        {
            string frase = tbFrase.Text.ToLower().Replace(" ","");
            if (tbFrase.Text.Length > 50) {
                MessageBox.Show("O texto precisa ser menor que 50 caracteres ");
                return;
            }
            string textReverso = new string(frase.Reverse().ToArray());
            MessageBox.Show($"O texto {(frase == textReverso ? "": "não")} é um palíndromo ");
        }
    }
}
