﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tipo_de_triangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!SetarValores())
            {
                MessageBox.Show("Valores invalidos ou campos vazios");
                return;
            }


            if (ladoA + ladoB > ladoC && ladoA + ladoC > ladoB && ladoB + ladoC > ladoA)
            {
                if (ladoA == ladoB && ladoA == ladoC && ladoB == ladoC)
                {
                    lbResultado.Text = "Triangulo equilatero";
                    pbImage.Image = Properties.Resources.trianguloEqui;
                }
                else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                {
                    lbResultado.Text = "Triangulo Isósceles";
                    pbImage.Image = Properties.Resources.trianguloIsosceles;
                }
                else if (ladoA != ladoB && ladoA != ladoC && ladoB != ladoC)
                {
                    lbResultado.Text = "Triangulo Escaleno";
                    pbImage.Image = Properties.Resources.trianguloEscale;
                }
            }
            else
            {
                lbResultado.Text = "Não é um Triangulo";
                pbImage.Image = null;
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            tbLadoA.Clear();
            tbLadoB.Clear();
            tbLadoC.Clear();
            pbImage.Image = null;
        }

        private void textboxApenasNumeros_TextChanged(object sender, KeyPressEventArgs e)
            {
            //verifica qual tecla foi pressionada, se for alguma diferente de numero, virgula ou sinal negativo não é registrada   
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
            }

            //verifica se ja tem uma virgula
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }

        }

        private bool SetarValores()
        {
            return Double.TryParse(tbLadoA.Text, out ladoA) && Double.TryParse(tbLadoB.Text, out ladoB) && Double.TryParse(tbLadoC.Text, out ladoC);
        }
    }
}
