﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atividade6
{
    class Mensalista : Empregado
    {
        public Mensalista(int matricula,string nome, DateTime dataEntrada, double salarioMensal)
        {
            this.Matricula = matricula;
            this.Nome = nome;
            this.DataEntradaEmpresa = dataEntrada;
            this.SalarioMensal = salarioMensal;
        }
        public Mensalista()
        {
           
        }
        public double SalarioMensal { get; set; }


        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
    }
}
