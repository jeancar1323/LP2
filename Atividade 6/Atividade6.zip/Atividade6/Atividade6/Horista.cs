﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atividade6
{
    class Horista : Empregado
    {
        public double NumeroHora { get; set; }

        public double SalarioHora { get; set; }

        public int DiasFalta { get; set; }

        public Horista(int matricula, string nome, DateTime dataEntrada, double numeroHora, double salarioHora, int diasFalta)
        {
            this.Matricula = matricula;
            this.Nome = nome;
            this.DataEntradaEmpresa = dataEntrada;
            this.NumeroHora = numeroHora;
            this.SalarioHora = salarioHora;
            this.DiasFalta = diasFalta;
        }
        public override double SalarioBruto()
        {
            return NumeroHora * SalarioHora;
        }

        public override int TempoDeEmpresa()
        {
            return base.TempoDeEmpresa() - DiasFalta;
        }
    }
}
