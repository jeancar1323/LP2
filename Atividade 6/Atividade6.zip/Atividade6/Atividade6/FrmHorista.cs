﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class FrmHorista : Form
    {
        public FrmHorista()
        {
            InitializeComponent();
        }

        private void FrmHorista_Load(object sender, EventArgs e)
        {
            dtpDataEntrada.MaxDate = DateTime.Today;
        }


        private void btnInstHorista_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
                return;

            Horista myHorista = new Horista(Convert.ToInt32(tbMatricula.Text), tbNome.Text, dtpDataEntrada.Value, Convert.ToDouble(tbHoras.Text), Convert.ToDouble(tbSalario.Text),
                Convert.ToInt32(tbDiasFalta.Text));

            MessageBox.Show($"Matricula: {myHorista.Matricula}\n" +
                $"Nome: {myHorista.Nome}\n" +
                $"Data Entrada: {myHorista.DataEntradaEmpresa}\n" +
                $"Salario Bruto: R${myHorista.SalarioBruto()}\n" +
                $"Tempo de Trabalho: {myHorista.TempoDeEmpresa()} dias");


        }

        private bool ValidarCampos()
        {
            if (String.IsNullOrEmpty(tbNome.Text))
            {
                MessageBox.Show("Campo nome não pode estar vazio");
                return false;
            }

            if (String.IsNullOrEmpty(tbMatricula.Text) || !Int32.TryParse(tbMatricula.Text, out int num))
            {
                MessageBox.Show("Campo matricula não pode estar vazio e precisa ser um numero");
                return false;
            }

            if (String.IsNullOrEmpty(tbSalario.Text) || !Double.TryParse(tbSalario.Text, out double num2))
            {
                MessageBox.Show("Campo salario não pode estar vazio e precisa ser um numero");
                return false;
            }

            if (String.IsNullOrEmpty(tbHoras.Text) || !Double.TryParse(tbHoras.Text, out double num3))
            {
                MessageBox.Show("Campo Horas não pode estar vazio e precisa ser um numero");
                return false;
            }

            if (String.IsNullOrEmpty(tbDiasFalta.Text) || !Int32.TryParse(tbDiasFalta.Text, out int num4))
            {
                MessageBox.Show("Campo Dia Falta não pode estar vazio e precisa ser um numero");
                return false;
            }

            return true;
        }

        private void textboxApenasNumeros_TextChanged(object sender, KeyPressEventArgs e)
        {
            //apenas deixar digitar numeros 
            if (!char.IsControl(e.KeyChar) && !char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textboxApenasNumerosEVirgula_TextChanged(object sender, KeyPressEventArgs e)
        {
            //verifica qual tecla foi pressionada, se for alguma diferente de numero, virgula ou sinal negativo não é registrada   
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
            }

            //verifica se ja tem uma virgula
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }

        }

       
    }
}
