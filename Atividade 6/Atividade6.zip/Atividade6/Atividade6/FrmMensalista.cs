﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class FrmMensalista : Form
    {
        public FrmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstMensalista_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
                return;
            Mensalista myMensalista = new Mensalista();
            myMensalista.Matricula = Convert.ToInt32(tbMatricula.Text);
            myMensalista.Nome = tbNome.Text;
            myMensalista.DataEntradaEmpresa = dtpDataEntrada.Value;
            myMensalista.SalarioMensal = Convert.ToDouble(tbSalario.Text);
            ShowMsg(myMensalista);

        }

        private void btnInstPara_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
                return;
            Mensalista myMensalista = new Mensalista(Convert.ToInt32(tbMatricula.Text), tbNome.Text, dtpDataEntrada.Value, Convert.ToDouble(tbSalario.Text));
            ShowMsg(myMensalista);
        }

        private void ShowMsg(Mensalista myMensalista) {

            MessageBox.Show($"Matricula: {myMensalista.Matricula}\n" +
               $"Nome: {myMensalista.Nome}\n" +
               $"Data Entrada: {myMensalista.DataEntradaEmpresa}\n" +
               $"Salario Bruto: R${myMensalista.SalarioBruto()}\n" +
               $"Tempo de Trabalho: {myMensalista.TempoDeEmpresa()} dias");
        }
        private bool ValidarCampos()
        {
            if (String.IsNullOrEmpty(tbNome.Text))
            {
                MessageBox.Show("Campo nome não pode estar vazio");
                return false;
            }

            if (String.IsNullOrEmpty(tbMatricula.Text) || !Int32.TryParse(tbMatricula.Text, out int num))
            {
                MessageBox.Show("Campo matricula não pode estar vazio e precisa ser um numero");
                return false;
            }

            if (String.IsNullOrEmpty(tbSalario.Text) || !Double.TryParse(tbSalario.Text, out double num2))
            {
                MessageBox.Show("Campo salario não pode estar vazio e precisa ser um numero");
                return false;
            }

            return true;
        }

        private void textboxApenasNumeros_TextChanged(object sender, KeyPressEventArgs e)
        {
            //apenas deixar digitar numeros 
            if (!char.IsControl(e.KeyChar) && !char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textboxApenasNumerosEVirgula_TextChanged(object sender, KeyPressEventArgs e)
        {
            //verifica qual tecla foi pressionada, se for alguma diferente de numero, virgula ou sinal negativo não é registrada   
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
            }

            //verifica se ja tem uma virgula
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }

        }

       
    }
}
