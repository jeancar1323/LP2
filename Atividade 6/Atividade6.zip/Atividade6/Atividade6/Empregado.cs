﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atividade6
{
    abstract class Empregado
    {
        private int matricula;
        private string nome;
        private DateTime dataEntradaEmpresa;

        public int Matricula { get => matricula; set => matricula = value; }
        public string Nome { get => nome; set => nome = value; }
        public DateTime DataEntradaEmpresa { get => dataEntradaEmpresa; set => dataEntradaEmpresa = value; }

        public abstract double SalarioBruto();

        public virtual int TempoDeEmpresa()
        {
            TimeSpan ts = DateTime.Today.Subtract(DataEntradaEmpresa);
            return ts.Days;
        }
    }
}
