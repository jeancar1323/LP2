﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
   public static class Calcular
    {

        public static double Somar(double n1, double n2)
        {
            return n1 + n2;
        }

        public static double Subtrair(double n1, double n2)
        {
            return n1 - n2;
        }

        public static double Multiplicar(double n1, double n2)
        {
            return n1 * n2;
        }

        public static double Dividir(double n1, double n2)
        {
            if(n2 == 0)
            {
                MessageBox.Show("Impossivel dividir por zero!");
                return Double.NaN;
            }

            return n1/n2;
        }


    }
}
