﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double n1, n2;

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            tbN1.Clear();
            tbN2.Clear();
            tbRes.Clear();
        }

        private void textboxApenasNumeros_TextChanged(object sender, KeyPressEventArgs e) {


            //verifica qual tecla foi pressionada, se for alguma diferente de numero, virgula ou sinal negativo não é registrada   
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ',') && (e.KeyChar != '-'))
            {
                e.Handled = true;
            }

            //verifica se ja tem um sinal negativo e apena deixa colocar o sinal negativo se ele for o primeiro
            if (((e.KeyChar == '-') && ((sender as TextBox).Text.IndexOf('-') > -1)) || ((e.KeyChar == '-') && (sender as TextBox).Text.Length > 1))
            {
                e.Handled = true;
            }

            //verifica se ja tem uma virgula
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }




        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            if (!SetarValores())
                return;
            tbRes.Text = Calcular.Somar(n1, n2).ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            if (!SetarValores())
                return;
            tbRes.Text = Calcular.Subtrair(n1, n2).ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            if (!SetarValores())
                return;
            tbRes.Text = Calcular.Multiplicar(n1, n2).ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (!SetarValores())
                return;
            tbRes.Text = Calcular.Dividir(n1, n2).ToString();
        }

        private Boolean SetarValores()
        {



            if (Double.TryParse(tbN1.Text, out n1) && Double.TryParse(tbN2.Text, out n2))
                return true;
            else
            {
                MessageBox.Show("Houve ao erro na calcular, provavelmente um dos caracteres não é um numero ou um ou mais campos estão em branco!");
                return false;
            }
                


        }
    }
}
