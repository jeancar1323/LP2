﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class Form1 : Form
    {
        double altura, peso;
        public Form1()
        {
            InitializeComponent();
        }



        #region clicks
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!SetarValores())
            {
                MessageBox.Show("Campos com valores invalidos");
                return;
            }
           
            lbResultado.Text = ImcMessage(CalcularIMC(altura, peso));
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void brnLimpar_Click(object sender, EventArgs e)
        {
            mtbAltura.Clear();
            mtbPeso.Clear();
            lbResultado.Text = "Aguardando calculo";
        }
        #endregion
        #region meus metodos
        private string ImcMessage(double imc)
        {
            string classificacao;
            if (imc < 18.5)
                classificacao = "Magreza";
            else if (imc < 25)
                classificacao = "Normal";
            else if (imc < 30)
                classificacao = "Sobrepeso";
            else if (imc <= 40)
                classificacao = "Obesidade";
            else
                classificacao = "Obesidade Grave";

            return $"Imc: {imc}\nclassificação: {classificacao}";
        }
        private bool SetarValores()
        {
            return Double.TryParse(mtbAltura.Text, out altura) && Double.TryParse(mtbPeso.Text, out peso);
        }

       

        private double CalcularIMC(double altura, double peso)
        {

            return Math.Round(peso / (altura * altura), 1);
        }
        #endregion

    }
}
